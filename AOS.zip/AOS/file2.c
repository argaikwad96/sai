#include<stdio.h>
#include<unistd.h>
int main()
{
printf("welcome to wadia College\n");
sleep(5);
printf("welcome in msc cs\n");
return 0;
}
