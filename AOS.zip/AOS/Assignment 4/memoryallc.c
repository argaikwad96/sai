#include <stdio.h>
#include <stdlib.h>

// Function that creates a memory leak
void create_memory_leak() {
    int *ptr = (int *)malloc(sizeof(int) * 10);
    // Use the memory block
    for (int i = 0; i < 10; i++) {
        ptr[i] = i;
    }
    // Do not free the memory block
}

// Function that fixes the memory leak
void fix_memory_leak() {
    int *ptr = (int *)calloc(10, sizeof(int));
    // Use the memory block
    for (int i = 0; i < 10; i++) {
        printf("Value at index %d: %d\n", i, ptr[i]);
    }
    // Free the memory block
    free(ptr);
}

int main() {
    printf("Creating a memory leak...\n");
    create_memory_leak();
    printf("Memory leak created.\n");

    printf("\nFixing the memory leak...\n");
    fix_memory_leak();
    printf("Memory leak fixed.\n");

    return 0;
}

