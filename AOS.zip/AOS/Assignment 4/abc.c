#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>  
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>

#define SHM_KEY 1234
#define SHM_SIZE 1024

  int main() {
    int shm_id;
    char *shm_ptr;
    pid_t pid;

    shm_id = shmget(SHM_KEY, SHM_SIZE, IPC_CREAT | 0666);

    shm_ptr = (char *) shmat(shm_id, NULL, 0);
   
    pid = fork();
   
    if (pid == 0) {
        sleep(2);  
        printf("Child process reads: %s\n", shm_ptr);

        snprintf(shm_ptr, SHM_SIZE, "I'm child");
	   printf("Child process writes: %s\n", shm_ptr);
        
        exit(0);
    } else {
        snprintf(shm_ptr, SHM_SIZE, "I'm parent");
        printf("Parent process writes: %s\n", shm_ptr);

        wait(NULL);

        printf("Parent process reads: %s\n", shm_ptr);
        
    }
    return 0;
}


 

