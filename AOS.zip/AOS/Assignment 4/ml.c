#include <stdio.h>
#include <stdlib.h>

int main() {
    
    int *ptr = (int*) malloc(sizeof(int) * 100);

    if (ptr == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    for (int i = 0; i < 100; i++) {
        ptr[i] = i;
    }

    printf("Memory allocated and used successfully\n");

    free(ptr);
    printf("Memory free (No Memory Leak)\n");

    return 0;
}
