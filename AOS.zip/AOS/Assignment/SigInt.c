#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

 void sig_handler(int signo){
	if(signo == SIGINT){
	   printf("Handling this SIGINT signal");
	}	
 }

int main(void){
   //int i=1;
   printf("Hello.....");
   if(signal(SIGINT,sig_handler) == SIG_ERR)
	printf("Cant catch"); 

   while(1)
     sleep(1);

return 0;
}
