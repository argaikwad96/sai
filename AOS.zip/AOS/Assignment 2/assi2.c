#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

#define BUFFER_SIZE 128

void deposit(int write_fd) {
    int amount = 10;  
    close(write_fd);   
    printf("Deposit process: Depositing %d\n", amount);
    write(write_fd, &amount, sizeof(amount));  
    exit(0);  
}

void withdraw(int read_fd) {
    int balance;
    read(read_fd, &balance, sizeof(balance)); 
    if (balance < 200) {
        printf("Withdraw process: Insufficient balance, going to sleep\n");
        sleep(5); 
    } else {
        printf("Withdraw process: Withdrawing 200\n");
        balance -= 200;  
        printf("Withdraw process: New balance %d\n", balance);
    }
    close(read_fd);   
    exit(0); 
}

void emi(int read_fd) {
    int balance;
    read(read_fd, &balance, sizeof(balance));  
    if (balance < 500) {
        printf("EMI process: Insufficient balance, going to sleep\n");
        sleep(5);  
    } else {
        printf("EMI process: Paying EMI of 500\n");
        balance -= 500; 
        printf("EMI process: New balance %d\n", balance);
    }
    close(read_fd);    
    exit(0); 
}

int main() {
    int pipe_fd[2]; 
    pid_t pid;

    if (pipe(pipe_fd) == -1) {  
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        deposit(pipe_fd[1]);  
    }

    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        close(pipe_fd[1]);  
        withdraw(pipe_fd[0]);  
    }

    
    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        close(pipe_fd[1]);  
        emi(pipe_fd[0]);  
    }

    
    close(pipe_fd[0]);  
    close(pipe_fd[1]);

    
    while (wait(NULL) > 0);

    return 0;
}

