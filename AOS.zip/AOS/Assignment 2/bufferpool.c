#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define BLOCK_SIZE 256

#define NUM_BLOCKS 10

typedef struct {
    char data[BLOCK_SIZE];
} buffer_block_t;

typedef struct {
    buffer_block_t* blocks;
    int num_blocks;
    int next_block;
} memory_pool_t;

void init_memory_pool(memory_pool_t* pool) {
    pool->blocks = (buffer_block_t*)malloc(NUM_BLOCKS * sizeof(buffer_block_t));
    pool->num_blocks = NUM_BLOCKS;
    pool->next_block = 0;
}

buffer_block_t* allocate_block(memory_pool_t* pool) {
    if (pool->next_block < pool->num_blocks) {
        return &pool->blocks[pool->next_block++];
    } else {
        return NULL; 
    }
}

void free_block(memory_pool_t* pool, buffer_block_t* block) {
    
    pool->next_block--;
}

int main() {
    memory_pool_t pool;
    init_memory_pool(&pool);

    buffer_block_t* block1 = allocate_block(&pool);
    strcpy(block1->data, "Hello, world!");

    buffer_block_t* block2 = allocate_block(&pool);
    strcpy(block2->data, "This is tejal.");

    buffer_block_t* block3 = allocate_block(&pool);
    strcpy(block3->data, "Thia is my Buffer block allocation demo.");

    printf("Block 1: %s\n", block1->data);
    printf("Block 2: %s\n", block2->data);
    printf("Block 3: %s\n", block3->data);

    free_block(&pool, block3);
    free_block(&pool, block2);
    free_block(&pool, block1);

    return 0;
}
