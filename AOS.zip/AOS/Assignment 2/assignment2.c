#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

#define BALANCE_FILE "balance.dat"

// Function to initialize the balance file
void init_balance(int initial_balance) {
    FILE *file = fopen(BALANCE_FILE, "w");
    if (!file) {
        perror("Failed to open balance file");
        exit(EXIT_FAILURE);
    }
    fprintf(file, "%d", initial_balance);
    fclose(file);
}

// Function to read balance from the file
int read_balance() {
    FILE *file = fopen(BALANCE_FILE, "r");
    int balance = 0;
    if (!file) {
        perror("Failed to open balance file");
        exit(EXIT_FAILURE);
    }
    fscanf(file, "%d", &balance);
    fclose(file);
    return balance;
}

// Function to write balance to the file
void write_balance(int balance) {
    FILE *file = fopen(BALANCE_FILE, "w");
    if (!file) {
        perror("Failed to open balance file");
        exit(EXIT_FAILURE);
    }
    fprintf(file, "%d", balance);
    fclose(file);
}

void deposit() {
    int amount;
    printf("Enter deposit amount: ");
    scanf("%d", &amount);

    int balance = read_balance();
    balance += amount;
    write_balance(balance);

    printf("Deposit process: Depositing %d\n", amount);
    exit(0);
}

void withdraw() {
    int withdraw_amount;
    int balance = read_balance();

    printf("Withdraw process: Current balance is %d\n", balance);
    printf("Enter withdrawal amount: ");
    scanf("%d", &withdraw_amount);

    if (balance < withdraw_amount) {
        printf("Withdraw process: Insufficient balance, going to sleep\n");
        sleep(5);
    } else {
        balance -= withdraw_amount;
        write_balance(balance);
        printf("Withdraw process: Withdrawing %d\n", withdraw_amount);
        printf("Withdraw process: New balance %d\n", balance);
    }
    exit(0);
}

void emi() {
    int emi_amount;
    int balance = read_balance();

    printf("EMI process: Current balance is %d\n", balance);
    printf("Enter EMI amount: ");
    scanf("%d", &emi_amount);

    if (balance < emi_amount) {
        printf("EMI process: Insufficient balance, going to sleep\n");
        sleep(5);
    } else {
        balance -= emi_amount;
        write_balance(balance);
        printf("EMI process: Paying EMI of %d\n", emi_amount);
        printf("EMI process: New balance %d\n", balance);
    }
    exit(0);
}

int main() {
    pid_t pid;

    // Initialize balance file with some amount
    init_balance(0);  // Starting balance

    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        deposit();
    }

    wait(NULL);

    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        withdraw();
    }

    wait(NULL);

    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        emi();
    }

    wait(NULL);

    // Clean up the balance file
    remove(BALANCE_FILE);

    return 0;
}

