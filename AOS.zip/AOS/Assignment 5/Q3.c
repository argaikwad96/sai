#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

void sigint_handler(int signum) {
    printf("Received SIGINT signal (Ctrl+C)\n");
    printf("Exiting program...\n");
    exit(0);
}

void sigterm_handler(int signum) {
    printf("Received SIGTERM signal (kill command)\n");
    printf("Exiting program...\n");
    exit(0);
}

int main() {
    signal(SIGINT, sigint_handler);
    signal(SIGTERM, sigterm_handler);

    printf("Program started. Press Ctrl+C to send SIGINT or use kill command to send SIGTERM...\n");

    while (1) {
	printf("tejal..\n");
        sleep(1);
    }

    return 0;
}
