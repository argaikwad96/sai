#include <signal.h>
#include <stdio.h>
#include <unistd.h>

volatile sig_atomic_t suspended = 0;

void signal_handler(int signal_num) {
    if (signal_num == SIGUSR1) {
        printf("Received SIGUSR1, suspending process...\n");
        suspended = 1;
    } else if (signal_num == SIGCONT) {
        printf("Received SIGCONT, resuming process...\n");
        suspended = 0;
    }
}

int main() {
    pid_t pid = getpid();
    printf("Process ID: %d\n", pid);

    // Register signal handler for SIGUSR1 and SIGCONT
    signal(SIGUSR1, signal_handler);
    signal(SIGCONT, signal_handler);

    while (1) {
        while (suspended) {
            pause(); // Wait for SIGCONT
        }
        printf("Process is running...\n");
        sleep(1);
    }

    return 0;
}
