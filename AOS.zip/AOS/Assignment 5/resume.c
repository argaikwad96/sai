#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

int is_suspended = 0;

void signalHandler(int signum) {
    if (signum == SIGTSTP) {
        if (is_suspended) {
            printf("Child process resumed.\n");
            is_suspended = 0;
        } else {
            printf("Child process suspended.\n");
            is_suspended = 1;
        }
    }
}

int main() {
    pid_t child_pid;

    if ((child_pid = fork()) == 0) {
        
        signal(SIGTSTP, signalHandler); 
        signal(SIGCONT, signalHandler); 

        while (1) {
           
            sleep(1);
        }
    } else if (child_pid > 0) {
        
        printf("Parent process started. \n Child PID: %d\n", child_pid);

      
        sleep(2);

        while (1) {
            
            kill(child_pid, SIGTSTP);
            sleep(2);

            
            kill(child_pid, SIGCONT);
            sleep(2);
        }
    } else {
        perror("fork");
        exit(1);
    }

    return 0;
}
