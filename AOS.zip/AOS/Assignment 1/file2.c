#include<stdio.h>
#include<unistd.h>
int main()
{
printf("welcome to wadia College\n");
sleep(7);
printf("welcome in msc cs\n");
return 0;
}
