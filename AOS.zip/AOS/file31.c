#include <stdio.h>
#include <string.h>
#include <dirent.h>

int findfileSize(const char *f_n) {
    FILE *fp = fopen(f_n, "r");
    if (fp == NULL) {
        printf("File not found!\n");
        return -1;
    }
    fseek(fp, 0L, SEEK_END);
    int res = ftell(fp);
    fclose(fp);
    return res;
}

void printFileExtension(const char *filename) {
    int i, show = 0;
    printf("File type = ");
    for (i = 0; i < strlen(filename); i++) {
        if (show || filename[i] == '.') {
            printf("%c", filename[i]);
            show = 1;
        }
    }
    printf("\n");
}

void listFilesInDirectory() {
    struct dirent *de;
    DIR *dr = opendir(".");
    int fileCount = 0;

    if (dr == NULL) {
        printf("Could not open the current directory\n");
        return;
    }

    while ((de = readdir(dr)) != NULL) {
        if (de->d_type == DT_REG) 
            fileCount++;
        }
    }

    closedir(dr);

    printf("Number of files in the current directory: %d\n", fileCount);
}

int main() {
    char filename[30];
    int fileSize;

    printf("Enter the file name:\n");
    scanf("%s", filename);

    printFileExtension(filename);
    fileSize = findfileSize(filename);
    if (fileSize != -1) {
        printf("Size of the file is %d bytes\n", fileSize);
    }

    listFilesInDirectory();

    return 0;
}

