#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void parent_cleanup() {
    printf("Parent cleanup\n");
}

void child_cleanup() {
    printf("Child cleanup\n");
}

int main() {
   
    atexit(parent_cleanup);

   
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);

    } else if (pid == 0) {
       
        atexit(child_cleanup);

        printf("Child process running...\n");

        exit(0);
    } else {
        
        printf("Parent process running...\n");

        wait(NULL);

        exit(0);
    }
}

