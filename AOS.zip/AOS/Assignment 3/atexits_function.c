#include <stdio.h>
#include <stdlib.h>

FILE *file;

void close_file() {
    if (file) {
        fclose(file);
        printf("File closed.\n");
    }
}

int main() {
    file = fopen("output.txt", "w");
    if (!file) {
        perror("Failed to open file");
        return 1;
    }

    atexit(close_file);  
   
    fprintf(file, "Hello, Tejal!\n");

    printf("Program is exiting...\n");
    return 0;
}

