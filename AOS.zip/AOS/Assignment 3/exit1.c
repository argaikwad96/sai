#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void parent_cleanup() {
    printf("Parent cleanup\n");
}

void child_cleanup() {
    printf("Child cleanup\n");
}

int main() {
   
    atexit(parent_cleanup);
    atexit(child_cleanup);
    printf("Program exit...\n");
   
    

        exit(0);
 }

