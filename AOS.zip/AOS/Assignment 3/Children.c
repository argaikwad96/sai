#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/resource.h>

int main() {
    int n, i;
    pid_t pid;
    struct rusage usage;
    long total_utime_sec = 0, total_utime_usec = 0;
    long total_stime_sec = 0, total_stime_usec = 0;

    
    printf("Enter the number of children to create: ");
    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        pid = fork();

        if (pid < 0) {
       
            perror("fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            
            printf("Child %d with PID %d is running\n", i+1, getpid());
            sleep(1); 
            exit(EXIT_SUCCESS); 
        }
    }

    
    for (i = 0; i < n; i++) {
        wait(NULL); 
        getrusage(RUSAGE_CHILDREN, &usage); 

        
        total_utime_sec += usage.ru_utime.tv_sec;
        total_utime_usec += usage.ru_utime.tv_usec;
        
        if (total_utime_usec >= 1000000) {
            total_utime_sec += 1;
            total_utime_usec -= 1000000;
        }

       
        total_stime_sec += usage.ru_stime.tv_sec;
        total_stime_usec += usage.ru_stime.tv_usec;
        
        if (total_stime_usec >= 1000000) {
            total_stime_sec += 1;
            total_stime_usec -= 1000000;
        }
    }

   
    printf("Total user mode time: %ld.%06ld seconds\n", total_utime_sec, total_utime_usec);
    printf("Total kernel mode time: %ld.%06ld seconds\n", total_stime_sec, total_stime_usec);

    return 0;
}

